'use strict';

// ============================================================================
//  2º DAW – Desarrollo Web en Entorno Cliente
//  Examen Primer Trimestre · Los Reyes Magos se modernizan
//  SOLUCIONES
// ============================================================================

// ============================================================================
//  DATOS DE PARTIDA (se entregan al alumnado)
// ============================================================================

const cartas = [
  { nombre: 'Lucía', edad: 7, ciudad: 'Zafra', juguetes: ['bicicleta', 'patines', 'puzle'], fechaEnvio: '02/12/2026' },
  { nombre: 'Hugo', edad: 10, ciudad: 'Mérida', juguetes: ['consola', 'videojuego', 'auriculares'], fechaEnvio: '15/11/2026' },
  { nombre: 'Martina', edad: 5, ciudad: 'Zafra', juguetes: ['muñeca', 'cocinita', 'plastilina'], fechaEnvio: '28/12/2026' },
  { nombre: 'Leo', edad: 8, ciudad: 'Badajoz', juguetes: ['patinete', 'balón', 'dron'], fechaEnvio: '03/01/2027' },
  { nombre: 'Sofía', edad: 12, ciudad: 'Mérida', juguetes: ['móvil', 'auriculares'], fechaEnvio: '20/10/2026' },
  { nombre: 'Mateo', edad: 6, ciudad: 'Almendralejo', juguetes: ['dinosaurio de verdad', 'bicicleta', 'puzle'], fechaEnvio: '30/12/2026' },
  { nombre: 'Valeria', edad: 9, ciudad: 'Zafra', juguetes: ['patines', 'libro', 'balón'], fechaEnvio: '05/01/2027' },
  { nombre: 'Daniel', edad: 11, ciudad: 'Badajoz', juguetes: ['consola', 'balón'], fechaEnvio: '07/01/2027' },
  { nombre: 'Carmen', edad: 4, ciudad: 'Almendralejo', juguetes: ['cocinita', 'muñeca', 'hermanito'], fechaEnvio: '10/12/2026' },
  { nombre: 'Pablo', edad: 13, ciudad: 'Mérida', juguetes: ['dron', 'consola', 'bicicleta'], fechaEnvio: '06/01/2027' },
  { nombre: 'Noa', edad: 8, ciudad: 'Zafra', juguetes: ['patinete', 'bicicleta', 'libro'], fechaEnvio: '22/11/2026' },
];

const catalogo = [
  { nombre: 'bicicleta', precio: 129.99, stock: 2 },
  { nombre: 'patines', precio: 45.50, stock: 1 },
  { nombre: 'puzle', precio: 12.95, stock: 10 },
  { nombre: 'consola', precio: 299.00, stock: 1 },
  { nombre: 'videojuego', precio: 59.90, stock: 5 },
  { nombre: 'auriculares', precio: 39.99, stock: 3 },
  { nombre: 'muñeca', precio: 24.95, stock: 4 },
  { nombre: 'cocinita', precio: 79.00, stock: 1 },
  { nombre: 'plastilina', precio: 6.50, stock: 20 },
  { nombre: 'patinete', precio: 149.00, stock: 2 },
  { nombre: 'balón', precio: 19.99, stock: 5 },
  { nombre: 'dron', precio: 89.00, stock: 1 },
  { nombre: 'libro', precio: 14.95, stock: 8 },
];

// ============================================================================
//  EJERCICIO 1 · Cartas por ciudad (2.5 puntos)
// ============================================================================

/**
 * Devuelve las cartas de la ciudad indicada, ordenadas por edad ascendente.
 * filter() crea un array nuevo, así que sort() ordena ese array y no `cartas`.
 */
function filtrarPorCiudad(ciudadBuscada) {
  const cartasPorCiudad = cartas.filter((carta) => carta.ciudad.toUpperCase() == ciudadBuscada.toUpperCase())
  const cartasOrdenadas = cartasPorCiudad.sort((a, b) => a.edad - b.edad);
  return cartasOrdenadas
}

function ejercicio1() {
  const ciudad = prompt('¿De qué ciudad quieres ver las cartas?');

  // Cancelar (null) o dejarlo vacío: no se muestra nada
  if (ciudad === null || ciudad.trim() == '') return;

  const cartasEncontradas = filtrarPorCiudad(ciudad);

  if (cartasEncontradas.length == 0) {
    alert(`No hay cartas de ${ciudad}`);
    return;
  }
  let rdo = '';
  for (const { nombre, edad, juguetes } of cartasEncontradas) {
    rdo += `${nombre} (${edad} años): ${juguetes}\n`;
  }
  alert(rdo);
}

// ============================================================================
//  EJERCICIO 2 · Presupuesto por carta (3 puntos)
// ============================================================================
/**
 * Calcula el presupuesto de una carta.
 */
function ejercicio2() {
  let noDisponibles = []
  let rdo = ""
  let presupuestoTotal = 0
  for (let { nombre, juguetes } of cartas) {
    // const nombre = carta.nombre
    // const juguetes = carta.juguetes
    let presupuesto = 0
    for (let nombreJuguete of juguetes) {
      const jugueteEncontrado = catalogo.find((prod) => prod.nombre == nombreJuguete)
      if (jugueteEncontrado != undefined) {
        presupuesto += jugueteEncontrado.precio
        presupuestoTotal += presupuesto
      } else {
        noDisponibles.push(nombreJuguete)
      }
    }
    rdo += `${nombre}: ${presupuesto}€<br/>`
  }
  rdo += `Total: ${presupuestoTotal.toFixed(2)}<br/>`
  rdo += "<h2>Juguetes no encontrados</h2>"
  rdo += noDisponibles
  document.querySelector("#resultados").innerHTML = rdo
}

// ============================================================================
//  EJERCICIO 3 · ¿Quién escribió a tiempo? (2 puntos)
// ============================================================================
/**
 * Si las cartas se envían con menos de 30 días de antelación, van en tiempo, si no, van retrasadas
 * Comparar las fechas usando el formato AñoMesDia como si fuesen números
 */

function ejercicio3() {
  let rdo = ""
  const DIAREYES = 20270106
  document.querySelector("#resultados").innerHTML = "<h3>¿Quién escribió a tiempo?</h3>"
  for (let carta of cartas) {
    const [dia, mes, año] = carta.fechaEnvio.split("/")
    const fecha = new Date(año, mes - 1, dia)
    fecha.setDate(fecha.getDate() + 30)
    const fechaDestino = `${fecha.getFullYear()}${(fecha.getMonth() + 1).toString().padStart(2, "0")}${fecha.getDate().toString().padStart(2, "0")}`
    if (fechaDestino > DIAREYES) {
      rdo += `<p>${carta.nombre} tu carta va <span class="rojo"> retrasada</span></p>\n`
    } else {
      rdo += `<p>${carta.nombre} tu carta va a tiempo</p>`
    }
  }
  document.querySelector("#resultados").innerHTML += rdo
}

// ============================================================================
//  EJERCICIO 4 · Clase Carta (2,5 puntos)
// ============================================================================

class Carta {
  static EDAD_MAXIMA = 14;
  static MAX_JUGUETES = 3;
  static #ultimoId = 0;

  #id;
  #nombre;
  #ciudad;
  #fechaEnvio;
  #edad;
  #juguetes = [];

  constructor(nombre, edad, ciudad) {
    this.edad = edad; // pasa por el setter, que valida y lanza RangeError si no es válida
    this.#id = ++Carta.#ultimoId;
    this.#nombre = nombre;
    this.#ciudad = ciudad
    this.#fechaEnvio = new Date().toLocaleDateString("es-ES")
  }

  get edad() {
    return this.#edad;
  }

  set edad(nuevaEdad) {
    if (!Number.isInteger(nuevaEdad) || !(nuevaEdad >= 1 && nuevaEdad <= Carta.EDAD_MAXIMA)) {
      throw new Error(`Edad no válida (${nuevaEdad}): debe ser un entero entre 1 y ${Carta.EDAD_MAXIMA}`);
    }
    this.#edad = nuevaEdad;
  }

  /** Devuelve el array interno. */
  get juguetes() {
    return this.#juguetes;
  }

  /**
   * Añade un juguete
   * Devuelve false si está vacío, repetido o si la carta ya está llena.
   */
  agregarJuguete(juguete) {
    if (juguete == ''
      || this.#juguetes.includes(juguete)
      || this.#juguetes.length >= Carta.MAX_JUGUETES) {
      return false;
    }
    this.#juguetes.push(juguete);
    return true;
  }

  toString() {
    return `#${this.#id} - ${this.#nombre
      } (${this.edad} años, ${this.#ciudad}): ${this.#juguetes.join(', ')} `;
  }
}

function ejercicio4() {
  const nombre = prompt('Nombre del niño o niña:');
  const edad = parseInt(prompt('Edad:'));
  const ciudad = prompt('Ciudad:');

  // Salir si se cancela un prompt o se deja algún dato vacío
  if (!nombre || Number.isNaN(edad) || !ciudad) {
    return;
  }
  let carta;
  try {
    carta = new Carta(nombre, edad, ciudad);
  } catch (error) {
    alert(`${error.message}. La carta no se crea.`);
    return;
  }

  while (carta.juguetes.length < Carta.MAX_JUGUETES) {
    const numero = carta.juguetes.length + 1;
    const juguete = prompt(`Juguete ${numero} de ${Carta.MAX_JUGUETES} (vacío o Cancelar para terminar): `);

    if (juguete === null || juguete.trim() == '') break;

    // Aquí el juguete no está vacío y la carta no está llena:
    // si agregarJuguete devuelve false es porque está repetido.
    if (!carta.agregarJuguete(juguete)) {
      alert(`"${juguete.trim()}" ya está en la carta`);
    }
  }

  if (carta.juguetes.length == 0) {
    alert('La carta no tiene juguetes: no se envía a los Reyes');
    return;
  }
  document.querySelector("#resultados").innerHTML = `<h3> Cartas creadas en esta sesión</h3 > <p>${carta}</p>`;
}


