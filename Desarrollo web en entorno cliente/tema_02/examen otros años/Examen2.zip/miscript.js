let animalesEnArca = [
    { nombre: "León", tipo: "carnívoro", sexo: "macho" },
    { nombre: "León", tipo: "carnívoro", sexo: "hembra" },
    { nombre: "Elefante", tipo: "herbívoro", sexo: "macho" },
    { nombre: "Elefante", tipo: "herbívoro", sexo: "hembra" },
    { nombre: "Delfín", tipo: "acuático", sexo: "macho" },
    { nombre: "Delfín", tipo: "acuático", sexo: "hembra" },
    { nombre: "Tigre", tipo: "carnívoro", sexo: "macho" },
    { nombre: "Jirafa", tipo: "herbívoro", sexo: "hembra" },
    { nombre: "Cebra", tipo: "herbívoro", sexo: "macho" },
    { nombre: "Tiburón", tipo: "acuático", sexo: "hembra" }
];

let curiosidades = [
    "Este animal será el encargado de dar la bienvenida hoy a los nuevos visitantes.",
    "¡Este animal ha ganado una ración extra de comida!",
    "Este animal será el primero en salir del arca cuando llegue el momento.",
    "Este animal tendrá el mejor camarote del arca hoy.",
    "Este animal liderará el paseo matutino por la cubierta."
];

let posiblesFechasDiluvio = ["15/03/2026", "22/06/2026", "10/09/2026", "25/03/2026", "01/06/2026"]

function filtrarPorTipo(tipo) {

}

function ejercicio1() {
    let tipo = prompt("Ingrese el tipo de animal a filtrar (carnívoro(C), herbívoro(H), acuático(A)):").toLowerCase();

}

function ejercicio2() {

}

function ejercicio3() {

    let mensaje = `<h3>🐾 Animal Aleatorio Seleccionado:</h3>`
    mensaje += `<p> <strong>Nombre:</strong> ${nombre}</p> `;
    mensaje += `<p> <strong>Tipo:</strong> ${tipo}</p > `;
    mensaje += `<p> <strong>Sexo:</strong> ${sexo}</p > `;
    mensaje += `<p> <em>Curiosidad:</em> ${curiosidadAleatoria}</p > `;
    document.querySelector("#rdo").innerHTML = mensaje
}

function ejercicio4() {
    const diasDemora = 146
    let mensaje = "<h3>🌧️ Preparándonos para el Próximo Diluvio:</h3>";

}