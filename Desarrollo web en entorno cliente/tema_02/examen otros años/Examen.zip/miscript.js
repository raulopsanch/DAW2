function ejercicio1() {
    let cadena = "fdsasVo14j1l1ettn567fsgrtboa iuyqverfvkiuarwqlkllkfe,iiuo prrraytqeersrra rrqearewl rrresghjiwsssgffuifdsafsernkjgtffbce 5555ejlkjjfmgettbrjjccdxi-l*ccopirtyo"
    let codificacion = "5-13-16-22-27-28-33-41-45-51-52-57-58-62-69-72-73-78-82-83-88-92-97-100-101-108-110-114-119-120-125-129-134-138-141-145-149-153-157"

}
function ejercicio2() {

    let deudas = ["Pedro:21/01/2024", "Luis:15/02/2024", "Antonio:04/04/2024", "Maria:05/06/2024", "Rafael:16/07/2024"]
    let semana = ["Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"]

}

function ejercicio3() {

}